module('bootstrap3-wysihtml5-bower.testframework', {

});
test("if test runner framework is working", function(){
  ok(true, "hope it works");
});
